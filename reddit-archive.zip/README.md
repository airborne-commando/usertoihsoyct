# usertoihsoyct
redirect when clicking a reddit username

How to install?

Open Firefox and go to ``about:debugging``

Click "This Firefox" in the left sidebar

Click "Load Temporary Add-on"

Select any of the files in your extension folder ``reddit-archive``.

Settings are in ``about:addons`` inside ``preferences``.

Works well with [reddit-uncensored](https://github.com/Fubs/reddit-uncensored)


You are free to add in a pull request for more features and raise issues.
